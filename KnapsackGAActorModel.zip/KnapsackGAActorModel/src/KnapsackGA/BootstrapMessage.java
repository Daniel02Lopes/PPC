package KnapsackGA;

import library.Message;

public class BootstrapMessage extends Message {
}
