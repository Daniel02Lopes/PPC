package KnapsackGA;

import library.Message;

public class MutatePopultionMessage extends Message {
}
