package KnapsackGA;

import library.Message;

public class GenerationIsFinish extends Message {
}
