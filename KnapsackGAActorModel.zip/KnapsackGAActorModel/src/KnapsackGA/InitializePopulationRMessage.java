package KnapsackGA;

import library.Message;

public class InitializePopulationRMessage extends Message {
}
