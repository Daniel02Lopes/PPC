package library;

import KnapsackGA.Individual;

public class Message {
}
