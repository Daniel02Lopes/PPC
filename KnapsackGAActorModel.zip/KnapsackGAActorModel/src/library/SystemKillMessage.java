package library;

public class SystemKillMessage extends Message {
}
