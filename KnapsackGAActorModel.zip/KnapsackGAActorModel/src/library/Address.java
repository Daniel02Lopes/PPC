package library;

@FunctionalInterface
public interface Address {
    public void sendMessage(Message m);
}
